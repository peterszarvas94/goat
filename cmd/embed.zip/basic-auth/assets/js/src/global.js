// This script is imported for all routes, but you can remove it from the head component
import "htmx.org";
import "htmx-ext-head-support";
import "htmx-ext-response-targets";
import "goat-ui";
